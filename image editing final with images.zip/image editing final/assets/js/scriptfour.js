
//pricing hover remove

let pricingBox = document.querySelector('.single_background');
pricingBox.addEventListener('mouseover', () => {
    pricingBox.classList.remove('single_background');
});

