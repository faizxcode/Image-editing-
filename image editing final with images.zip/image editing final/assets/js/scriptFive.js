//redirect index page
let closeBtn = document.querySelector('.closeButton');
closeBtn.addEventListener('click', () => {
    location.href = 'index.html';
});

