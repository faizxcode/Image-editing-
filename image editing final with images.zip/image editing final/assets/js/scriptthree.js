//redirect 
// let tabOne = document.querySelector('.quoteBoxZero');
// tabOne.addEventListener('click', () => {
//     location.href = 'customQuote.html';
// });
// let tabtwo = document.querySelector('.quoteBox_one');

// tabtwo.addEventListener('click', () => {
//     location.href = 'info.html';
// });
// let tabthree = document.querySelector('.quoteBox_two');

// tabthree.addEventListener('click', () => {
//     location.href = 'upload.html';
// });
// let tabfour = document.querySelector('.quoteBox_three');

// tabfour.addEventListener('click', () => {
//     location.href = 'information.html';
// });
