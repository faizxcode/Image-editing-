let closesideBtn = document.querySelector('.sidebarClose');
let removeclassarea = document.querySelector('.sidebar');

closesideBtn.addEventListener('click', () => {
    removeclassarea.classList.remove('sidebarshow');
});




